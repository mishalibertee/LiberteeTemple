var SomWebBrowser = pc.createScript('_som_webBrowser');
SomWebBrowser.attributes.add('url', {type: 'string'});
SomWebBrowser.prototype.initialize = function() {
};